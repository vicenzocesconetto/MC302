enum PaymentMethod {
    CREDITCARD, CASH, FREE;
}