public class SystemLiftException extends Exception{
}
