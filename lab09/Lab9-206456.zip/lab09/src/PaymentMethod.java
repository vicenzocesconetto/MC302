public enum PaymentMethod {
    CREDITCARD, CASH, FREE;
}