public interface Savable {

    public boolean saveToFile();

    public String originalToString();
}
